package com.example.payment;

public class Stripe {
    public void charge(double amount) {
        System.out.println("Charging $" + amount + " through Stripe.");
    }
}
