package com.example.payment;

public class AdapterPatternExample {
    public static void main(String[] args) {
        PayPal payPal = new PayPal();
        Stripe stripe = new Stripe();
        PaymentProcessor payPalAdapter = new PayPalAdapter(payPal);
        PaymentProcessor stripeAdapter = new StripeAdapter(stripe);
        payPalAdapter.processPayment(100.00);
        stripeAdapter.processPayment(200.00);
    }
}
