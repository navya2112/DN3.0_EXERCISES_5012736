package com.example.imageviewer;

public interface Image {
    void display();
}
