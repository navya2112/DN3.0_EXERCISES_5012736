package com.example.mvcc;

import com.example.mvc.model.Student;
import com.example.mvc.view.StudentView;
import com.example.mvc.controller.StudentController;

public class MVCPatternExample {
    public static void main(String[] args) {
        Student student = new Student();
        student.setName("John Doe");
        student.setId("12345");
        student.setGrade("A");

        StudentView view = new StudentView();

        StudentController controller = new StudentController(student, view);

        controller.updateView();

        controller.setStudentName("Jane Doe");
        controller.setStudentGrade("A+");

        controller.updateView();
    }
}
