package com.example.customer;

public interface CustomerRepository {
    Customer findCustomerById(int id);
}
