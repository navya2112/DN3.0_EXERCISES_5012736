package com.example.homeautomation;

public interface Command {
    void execute();
}
