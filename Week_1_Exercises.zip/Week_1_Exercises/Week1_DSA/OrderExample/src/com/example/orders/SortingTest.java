package com.example.orders;

import java.util.Arrays;

public class SortingTest {
    public static void main(String[] args) {
      
        Order[] orders = {
            new Order("O002", "Alice", 250.50),
            new Order("O003", "Bob", 150.75),
            new Order("O001", "Charlie", 300.00)
        };

        System.out.println("Unsorted Orders:");
        for (Order order : orders) {
            System.out.println(order);
        }

        Order[] bubbleSortedOrders = Arrays.copyOf(orders, orders.length);
        SortingAlgorithms.bubbleSort(bubbleSortedOrders);
        System.out.println("\nOrders Sorted by Bubble Sort:");
        for (Order order : bubbleSortedOrders) {
            System.out.println(order);
        }

        Order[] quickSortedOrders = Arrays.copyOf(orders, orders.length);
        SortingAlgorithms.quickSort(quickSortedOrders, 0, quickSortedOrders.length - 1);
        System.out.println("\nOrders Sorted by Quick Sort:");
        for (Order order : quickSortedOrders) {
            System.out.println(order);
        }
    }
}
