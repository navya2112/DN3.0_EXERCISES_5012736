package com.example.ecommerce;

import java.util.Arrays;

public class SearchTest {
    public static void main(String[] args) {
        Product[] products = {
            new Product("P002", "Smartphone", "Electronics"),
            new Product("P003", "Tablet", "Electronics"),
            new Product("P001", "Laptop", "Electronics")
        };
        Arrays.sort(products, (p1, p2) -> p1.getProductId().compareTo(p2.getProductId()));

        String searchId = "P002";
        Product result = SearchAlgorithms.linearSearch(products, searchId);
        System.out.println("Linear Search Result: " + result);

        result = SearchAlgorithms.binarySearch(products, searchId);
        System.out.println("Binary Search Result: " + result);
    }
}
