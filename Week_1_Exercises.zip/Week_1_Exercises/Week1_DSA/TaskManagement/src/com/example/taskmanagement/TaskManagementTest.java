package com.example.taskmanagement;

public class TaskManagementTest {
    public static void main(String[] args) {
        SinglyLinkedList taskList = new SinglyLinkedList();

        taskList.addTask(new Task("T001", "Design", "In Progress"));
        taskList.addTask(new Task("T002", "Development", "Not Started"));
        taskList.addTask(new Task("T003", "Testing", "Completed"));

        System.out.println("Task List:");
        taskList.traverseTasks();

        Task task = taskList.searchTaskById("T002");
        if (task != null) {
            System.out.println("\nFound Task: " + task);
        } else {
            System.out.println("\nTask not found.");
        }

       
        boolean isDeleted = taskList.deleteTaskById("T001");
        if (isDeleted) {
            System.out.println("\nTask T001 deleted.");
        } else {
            System.out.println("\nTask T001 not found.");
        }

        
        System.out.println("\nTask List After Deletion:");
        taskList.traverseTasks();
    }
}
