package com.example.employee;

public class EmployeeManagementTest {
    public static void main(String[] args) {
        EmployeeManagementSystem system = new EmployeeManagementSystem(5);

        
        system.addEmployee(new Employee("E001", "Alice", "Developer", 60000));
        system.addEmployee(new Employee("E002", "Bob", "Manager", 75000));
        system.addEmployee(new Employee("E003", "Charlie", "Analyst", 55000));

       
        System.out.println("Employee List:");
        system.traverseEmployees();

      
        Employee employee = system.searchEmployeeById("E002");
        if (employee != null) {
            System.out.println("\nFound Employee: " + employee);
        } else {
            System.out.println("\nEmployee not found.");
        }

       
        boolean isDeleted = system.deleteEmployeeById("E001");
        if (isDeleted) {
            System.out.println("\nEmployee E001 deleted.");
        } else {
            System.out.println("\nEmployee E001 not found.");
        }

       
        System.out.println("\nEmployee List After Deletion:");
        system.traverseEmployees();
    }
}
