package com.example.financial;
import java.util.HashMap;
import java.util.Map;
public class FinancialForecast {
	/*public double calculateFutureValue(double currentValue, double growthRate, int years) {
        if (years == 0) {
            return currentValue; 
        } else {
           
            double futureValueForPreviousYear = calculateFutureValue(currentValue, growthRate, years - 1);
            return futureValueForPreviousYear * (1 + growthRate);
        }
    }*/
	private Map<Integer, Double> memo = new HashMap<>();
    public double calculateFutureValue(double currentValue, double growthRate, int years) {
        if (years == 0) {
            return currentValue; // Base case
        }
        if (memo.containsKey(years)) {
            return memo.get(years); // Return memoized result
        }

        double futureValueForPreviousYear = calculateFutureValue(currentValue, growthRate, years - 1);
        double futureValue = futureValueForPreviousYear * (1 + growthRate);
        memo.put(years, futureValue); // Memoize the result
        return futureValue;
    }

    public static void main(String[] args) {
        FinancialForecast forecast = new FinancialForecast();
        double currentValue = 1000.0; 
        double growthRate = 0.05; 
        int years = 10; 

        double futureValue = forecast.calculateFutureValue(currentValue, growthRate, years);
        System.out.println("Future Value after " + years + " years: " + futureValue);
    }
}
