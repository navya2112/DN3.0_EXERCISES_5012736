package com.example.library;

import java.util.Arrays;

public class LibraryManagementTest {
    public static void main(String[] args) {
       
        LibraryManagementSystem library = new LibraryManagementSystem();

        
        Book[] books = {
            new Book("B001", "The Great Gatsby", "F. Scott Fitzgerald"),
            new Book("B002", "1984", "George Orwell"),
            new Book("B003", "To Kill a Mockingbird", "Harper Lee")
        };

       
        library.sortBooksByTitle(books);

        
        Book book = library.linearSearchByTitle(books, "1984");
        if (book != null) {
            System.out.println("Linear Search - Found Book: " + book);
        } else {
            System.out.println("Linear Search - Book not found.");
        }

        
        book = library.binarySearchByTitle(books, "1984");
        if (book != null) {
            System.out.println("Binary Search - Found Book: " + book);
        } else {
            System.out.println("Binary Search - Book not found.");
        }
    }
}
