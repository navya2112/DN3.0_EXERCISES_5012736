package com.example.inventory;

public class InventorySystem {
    public static void main(String[] args) {
        InventoryManager manager = new InventoryManager();

        
        Product product1 = new Product("P001", "Laptop", 10, 999.99);
        Product product2 = new Product("P002", "Smartphone", 20, 499.99);
        manager.addProduct(product1);
        manager.addProduct(product2);

        System.out.println("All Products:");
        manager.displayAllProducts();

        product1.setPrice(899.99);
        manager.updateProduct(product1);

        System.out.println("Updated Product:");
        System.out.println(manager.getProduct("P001"));

        manager.deleteProduct("P002");

        System.out.println("All Products After Deletion:");
        manager.displayAllProducts();
    }
}
