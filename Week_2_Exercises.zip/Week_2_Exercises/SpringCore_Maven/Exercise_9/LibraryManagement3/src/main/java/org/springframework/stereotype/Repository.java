package org.springframework.stereotype;

public class Repository {

}
