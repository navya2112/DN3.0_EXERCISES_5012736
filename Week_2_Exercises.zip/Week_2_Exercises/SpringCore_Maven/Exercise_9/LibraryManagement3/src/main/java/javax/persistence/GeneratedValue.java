package javax.persistence;

public class GeneratedValue {

}
