package com.library.repository;

public interface BookRepositoryy {

}
